// script.js

function confirmLogout() {
    return confirm("Are you sure you want to logout?");
}

function validateForm() {
    const title = document.querySelector('input[name="title"]');
    const desc = document.querySelector('textarea[name="description"]');

    if (!title.value.trim() || !desc.value.trim()) {
        alert("Please fill in all fields.");
        return false;
    }

    return true;
}
