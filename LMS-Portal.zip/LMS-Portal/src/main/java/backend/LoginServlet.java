package backend;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        PrintWriter out = res.getWriter();
        res.setContentType("text/html");
        
        // Get parameters
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String role = req.getParameter("role");
        
        out.println("<html><body>");
        out.println("<h3>Debug Information:</h3>");
        out.println("<p>Email: " + email + "</p>");
        out.println("<p>Role from form: " + role + "</p>");
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/lms_portal", "root", "1234");
            
            PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE email=? AND password=?");
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                out.println("<p>User found in database</p>");
                out.println("<p>User ID: " + rs.getInt("id") + "</p>");
                out.println("<p>User Name: " + rs.getString("name") + "</p>");
                
                // Check if role column exists in the database
                ResultSetMetaData rsmd = rs.getMetaData();
                int columnCount = rsmd.getColumnCount();
                boolean roleColumnExists = false;
                
                out.println("<p>Database columns:</p><ul>");
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = rsmd.getColumnName(i);
                    out.println("<li>" + columnName + "</li>");
                    if (columnName.equalsIgnoreCase("role")) {
                        roleColumnExists = true;
                    }
                }
                out.println("</ul>");
                
                if (roleColumnExists) {
                    out.println("<p>Database role: " + rs.getString("role") + "</p>");
                } else {
                    out.println("<p>No role column found in database</p>");
                }
                
                HttpSession session = req.getSession();
                session.setAttribute("user_id", rs.getInt("id"));
                session.setAttribute("name", rs.getString("name"));
                
                // Use form role or database role
                if (roleColumnExists) {
                    session.setAttribute("role", rs.getString("role"));
                    out.println("<p>Using database role: " + rs.getString("role") + "</p>");
                } else {
                    session.setAttribute("role", role);
                    out.println("<p>Using form role: " + role + "</p>");
                }
                
                out.println("<p>Redirecting to: " + (role.equals("student") ? "student_dashboard.jsp" : "faculty-dashboard.jsp") + "</p>");
                out.println("<p><a href='" + (role.equals("student") ? "student_dashboard.jsp" : "faculty-dashboard.jsp") + "'>Click here to continue</a></p>");
                
                // Commented out automatic redirect for debugging
                // if (role.equals("student")) {
                //     res.sendRedirect("student_dashboard.jsp");
                // } else {
                //     res.sendRedirect("teacher_dashboard.jsp");
                // }
            } else {
                out.println("<p>User not found in database</p>");
                out.println("<p><a href='login.jsp?error=Invalid+email+or+password'>Return to login</a></p>");
            }
        } catch (Exception e) {
            out.println("<h3>Error:</h3>");
            out.println("<p>" + e.getMessage() + "</p>");
            out.println("<pre>");
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            out.println(sw.toString());
            out.println("</pre>");
        }
        
        out.println("</body></html>");
    }
}