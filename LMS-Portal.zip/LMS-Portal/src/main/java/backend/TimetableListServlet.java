package backend;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class TimetableListServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        List<Map<String, String>> files = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lms_portal", "root", "1234");

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT filename, filepath FROM timetables");

            while (rs.next()) {
                Map<String, String> map = new HashMap<>();
                map.put("filename", rs.getString("filename"));
                map.put("filepath", rs.getString("filepath"));
                files.add(map);
            }

            conn.close();
            request.setAttribute("files", files);
            RequestDispatcher rd = request.getRequestDispatcher("timetable.jsp");
            rd.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
