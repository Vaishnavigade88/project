package backend;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

public class MarksServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        if (role == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String studentId = request.getParameter("student_id");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/lms_portal", "root", "1234");

            if (role.equals("teacher")) {
                String subject = request.getParameter("subject");
                String marks = request.getParameter("marks");

                PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO marks (student_id, subject, marks) VALUES (?, ?, ?)");
                stmt.setString(1, studentId);
                stmt.setString(2, subject);
                stmt.setString(3, marks);

                stmt.executeUpdate();
                conn.close();

                response.sendRedirect("marks.jsp");

            } else if (role.equals("student")) {
                PreparedStatement stmt = conn.prepareStatement(
                    "SELECT subject, marks FROM marks WHERE student_id = ? OR student_id IN (SELECT id FROM users WHERE name = ?)");
                stmt.setString(1, studentId);
                stmt.setString(2, studentId);

                ResultSet rs = stmt.executeQuery();
                List<Map<String, String>> records = new ArrayList<>();

                while (rs.next()) {
                    Map<String, String> row = new HashMap<>();
                    row.put("subject", rs.getString("subject"));
                    row.put("marks", rs.getString("marks"));
                    records.add(row);
                }

                request.setAttribute("records", records);
                conn.close();

                RequestDispatcher rd = request.getRequestDispatcher("marks.jsp");
                rd.forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
