package backend;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class MarksServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String student = request.getParameter("student");
        String subject = request.getParameter("subject");
        int marks = Integer.parseInt(request.getParameter("marks"));

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO marks (student, subject, marks) VALUES (?, ?, ?)"
            );
            stmt.setString(1, student);
            stmt.setString(2, subject);
            stmt.setInt(3, marks);
            stmt.executeUpdate();

            response.sendRedirect("marks.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
