package backend;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MaterialListServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String UPLOAD_DIR = "uploads";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIR;
        File folder = new File(uploadPath);
        List<String> materials = new ArrayList<>();

        if (folder.exists() && folder.isDirectory()) {
            for (File file : folder.listFiles()) {
                materials.add(UPLOAD_DIR + "/" + file.getName());
            }
        }

        request.setAttribute("materials", materials);
        RequestDispatcher dispatcher = request.getRequestDispatcher("materials.jsp");
        dispatcher.forward(request, response);
    }
}
