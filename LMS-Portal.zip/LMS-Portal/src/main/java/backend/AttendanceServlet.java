package backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class AttendanceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Teacher submits attendance
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String studentId = request.getParameter("studentId");
        String date = request.getParameter("date");
        String status = request.getParameter("status");

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO attendance (student_id, date, status) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, studentId);
            stmt.setString(2, date);
            stmt.setString(3, status);

            int rowsInserted = stmt.executeUpdate();

            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            if (rowsInserted > 0) {
                out.println("<h3>Attendance submitted successfully!</h3>");
            } else {
                out.println("<h3>Failed to submit attendance.</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }

    // Student views attendance (with filter and percentage)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String studentId = request.getParameter("studentId");
        String monthParam = request.getParameter("month");

        List<Map<String, String>> attendanceRecords = new ArrayList<>();
        int totalDays = 0;
        int presentDays = 0;

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT date, status FROM attendance WHERE student_id = ?";
            if (monthParam != null && !monthParam.isEmpty()) {
                sql += " AND MONTH(date) = ?";
            }

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, studentId);
            if (monthParam != null && !monthParam.isEmpty()) {
                stmt.setInt(2, Integer.parseInt(monthParam));
            }

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Map<String, String> record = new HashMap<>();
                record.put("date", rs.getString("date"));
                record.put("status", rs.getString("status"));
                attendanceRecords.add(record);

                totalDays++;
                if ("Present".equalsIgnoreCase(rs.getString("status"))) {
                    presentDays++;
                }
            }

            // Calculate percentage
            int percentage = (totalDays > 0) ? (presentDays * 100 / totalDays) : 0;

            request.setAttribute("attendanceRecords", attendanceRecords);
            request.setAttribute("percentage", percentage);
            request.setAttribute("totalDays", totalDays);
            request.setAttribute("presentDays", presentDays);

            request.getRequestDispatcher("attendance.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
