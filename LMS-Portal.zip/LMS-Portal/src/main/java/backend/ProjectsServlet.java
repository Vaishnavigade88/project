package backend;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

 
public class ProjectsServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String title = request.getParameter("title");
        String description = request.getParameter("description");

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO projects (title, description) VALUES (?, ?)"
            );
            stmt.setString(1, title);
            stmt.setString(2, description);
            stmt.executeUpdate();

            response.sendRedirect("projects.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}