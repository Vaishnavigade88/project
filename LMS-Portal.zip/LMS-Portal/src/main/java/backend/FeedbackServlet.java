package backend;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class FeedbackServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String studentId = request.getParameter("studentId");
        String feedbackText = request.getParameter("feedbackText");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lms_portal", "root", "1234");
            PreparedStatement ps = conn.prepareStatement("INSERT INTO feedback (student_id, feedback_text) VALUES (?, ?)");
            ps.setString(1, studentId);
            ps.setString(2, feedbackText);
            ps.executeUpdate();

            conn.close();
            response.sendRedirect("feedback.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
