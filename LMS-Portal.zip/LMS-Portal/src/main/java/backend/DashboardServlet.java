package backend;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the session object
        HttpSession session = request.getSession(false);

        // Check if the user is logged in (session is not null and has user details)
        if (session != null && session.getAttribute("username") != null) {
            // Forward to dashboard page if user is logged in
            request.getRequestDispatcher("dashboard.jsp").forward(request, response);
        } else {
            // Redirect to login page if not logged in
            response.sendRedirect("index.jsp");
        }
    }
}
