package backend;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class MaterialServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        String link = request.getParameter("link");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lms_portal", "root","1234");

            PreparedStatement ps = conn.prepareStatement("INSERT INTO materials (title, link) VALUES (?, ?)");
            ps.setString(1, title);
            ps.setString(2, link);
            ps.executeUpdate();

            conn.close();
            response.sendRedirect("materials.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
