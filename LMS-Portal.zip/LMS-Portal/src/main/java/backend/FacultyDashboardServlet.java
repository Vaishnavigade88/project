package backend;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class FacultyDashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward to the JSP page
        RequestDispatcher rd = request.getRequestDispatcher("faculty-dashboard.jsp");
        rd.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response); // Optionally handle POST same as GET
    }
}
