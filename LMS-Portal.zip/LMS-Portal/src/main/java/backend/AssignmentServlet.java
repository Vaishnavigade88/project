package backend;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class AssignmentServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        String description = request.getParameter("description"); // Corrected variable name

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish database connection
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lms_portal", "root", "1234");

            // Prepare the SQL query to insert data into the assignments table
            PreparedStatement ps = conn.prepareStatement("INSERT INTO assignments (title, description) VALUES (?, ?)");
            ps.setString(1, title);
            ps.setString(2, description);

            // Execute the query
            ps.executeUpdate();

            // Close the connection
            conn.close();

            // Redirect to the assignments.jsp page
            response.sendRedirect("assignments.jsp");

        } catch (Exception e) {
            // Print the exception stack trace for debugging
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
